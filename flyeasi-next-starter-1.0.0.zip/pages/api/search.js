export default async function handler(req, res){
  if (req.method !== 'POST') return res.status(405).send('Method not allowed')
  try{
    const { TIQWA_BASE_URL, TIQWA_SEARCH_PATH, TIQWA_TOKEN, TIQWA_METHOD } = process.env
    let base = (TIQWA_BASE_URL||'').replace(/\/$/,'')
    let path = TIQWA_SEARCH_PATH || '/v1/flights/search'
    let url = path.startsWith('http') ? path : `${base}/${path.replace(/^\//,'')}`
    const method = (TIQWA_METHOD||'POST').toUpperCase()
    const headers = {'Content-Type':'application/json'}
    if (TIQWA_TOKEN) headers['Authorization'] = `Bearer ${TIQWA_TOKEN}`

    const body = req.body || {}
    // Always send IATA codes only if form had "City (IATA)"
    const norm = JSON.parse(JSON.stringify(body))

    const tried = [url]
    let resp = await fetch(url, {
      method,
      headers,
      body: method==='GET' ? undefined : JSON.stringify(norm)
    })
    // If 404 and we used base+relative path, try common alternates
    if (resp.status === 404 && !path.startsWith('http') && base){
      const alts = [`${base}/v1/flights/search`, `${base}/v1/flight/flights/search`]
      for (const cand of alts){
        if (cand === url) continue
        tried.push(cand)
        const r2 = await fetch(cand, { method, headers, body: method==='GET'?undefined:JSON.stringify(norm) })
        if (r2.ok){ resp = r2; break }
      }
    }
    if (!resp.ok){
      const text = await resp.text()
      return res.status(resp.status).send(text || `HTTP ${resp.status}`)
    }
    const json = await resp.json()
    // Attach tried URLs for diagnostics
    if (json && typeof json === 'object') json.__tried = tried
    return res.status(200).json(json)
  }catch(e){
    return res.status(500).send('Proxy error: '+e.message)
  }
}
