import Header from '@/components/Header'
export default function Review(){
  return (<div><Header/><div className="container"><div className="card"><b>Review</b><p>Offer details will appear here after selection.</p></div></div></div>)
}
