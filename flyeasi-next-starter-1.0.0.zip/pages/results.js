import {useEffect, useMemo, useState} from 'react'
import Header from '@/components/Header'
import { useRouter } from 'next/router'
import { iata, hm, timeHHMM } from '@/lib/utils'

function normalizePayload(q){
  const slices = []
  if (q.origin && q.destination && q.departure_date){
    slices.push({ origin:iata(q.origin), destination:iata(q.destination), departure_date:q.departure_date })
  }
  if (q.trip==='return' && q.return_date){
    slices.push({ origin:iata(q.destination), destination:iata(q.origin), departure_date:q.return_date })
  }
  const payload = {
    slices,
    origin: slices[0]?.origin || '',
    destination: slices[0]?.destination || '',
    departure_date: slices[0]?.departure_date || '',
    return_date: slices[1]?.departure_date || '',
    from: slices[0]?.origin || '',
    to: slices[0]?.destination || '',
    adults: Number(q.adults||1),
    cabin: String(q.cabin||'ECONOMY')
  }
  return payload
}

function pickOffers(api){
  if (!api) return []
  if (Array.isArray(api)) return api
  if (Array.isArray(api.offers)) return api.offers
  if (Array.isArray(api.data)) return api.data
  if (Array.isArray(api.results)) return api.results
  return []
}

function priceText(o){
  if (!o) return ''
  if (o.amount){ return (o.currency? o.currency+' ': '') + Number(o.amount).toLocaleString() }
  if (o.price?.total) return String(o.price.total)
  if (typeof o.price === 'string') return o.price
  if (typeof o.price === 'number') return String(o.price)
  return ''
}

function parseSegments(offer){
  // Try common shapes
  const out = offer.outbound || offer.itineraries?.[0]?.segments || offer.segments || []
  const inn = offer.inbound || offer.itineraries?.[1]?.segments || []
  return {out, inn}
}

function segmentTimes(seg){ return { dep: seg.departure_time || seg.departure, arr: seg.arrival_time || seg.arrival } }

export default function Results(){
  const r = useRouter()
  const q = r.query
  const [diag, setDiag] = useState(null)
  const [err, setErr] = useState(null)
  const [rows, setRows] = useState([])

  const payload = useMemo(()=> normalizePayload(q), [q])

  useEffect(()=>{
    if (!payload.origin || !payload.destination || !payload.departure_date) return
    const run = async () => {
      setErr(null); setDiag(null); setRows([])
      try{
        const res = await fetch('/api/search', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) })
        const info = { method:'POST', url:'(see serverless log)', payload }
        if (!res.ok){
          const text = await res.text()
          setDiag(info)
          setErr(`Search failed (HTTP ${res.status}). ${text.slice(0,200)}`)
          return
        }
        const json = await res.json()
        setDiag({...info, tried: json.__tried || []})
        setRows(pickOffers(json))
      }catch(e){
        setErr('Network error: '+ e.message)
        setDiag({ method:'POST', url:'(local)', payload })
      }
    }
    run()
  }, [payload.origin, payload.destination, payload.departure_date, payload.return_date, payload.cabin, payload.adults])

  return (
    <div>
      <Header/>
      <div className="container">
        <div style={{display:'flex',gap:8,flexWrap:'wrap'}} className="pills">
          <span className="badge">Best</span>
          <span className="badge">Cheapest</span>
          <span className="badge">Fastest</span>
        </div>

        {err && <div className="error">{err}</div>}

        {diag && <div className="card">
          <div><b>Diagnostics</b></div>
          <div><b>Payload</b></div>
          <div className="codebox">{JSON.stringify(payload)}</div>
          {Array.isArray(diag.tried) && <div><b>Tried URLs</b><div className="codebox">{JSON.stringify(diag.tried)}</div></div>}
          <div className="small">If 404, check Search Path in settings; if 405, switch POST/GET; if 0, SSL on host.</div>
        </div>}

        {rows.map((row, idx) => {
          const offer = row.raw || row
          const {out, inn} = parseSegments(offer)
          const depOut = out?.[0] ? segmentTimes(out[0]).dep : null
          const arrOut = out?.[out.length-1] ? segmentTimes(out[out.length-1]).arr : null
          const depIn = inn?.[0] ? segmentTimes(inn[0]).dep : null
          const arrIn = inn?.[inn.length-1] ? segmentTimes(inn[inn.length-1]).arr : null
          const stopsOut = Math.max((out?.length||1)-1, 0)
          const stopsIn = Math.max((inn?.length||1)-1, 0)

          return (
            <div className="card result-card" key={idx}>
              <div>
                <div className="result-hdr">
                  <div className="small">{offer.airline || offer.airline_details?.name || ' '}</div>
                  <div className="small">{offer.fare_basis || ''}</div>
                </div>
                {out?.length>0 && <div style={{marginBottom:8}}>
                  <div className="small">Outbound</div>
                  <div className="times">
                    <div><div className="badge">{timeHHMM(depOut)}</div></div>
                    <div><div className="badge">{stopsOut? `${stopsOut} stops` : 'direct'}</div></div>
                    <div><div className="badge">{timeHHMM(arrOut)}</div></div>
                  </div>
                </div>}
                {inn?.length>0 && <div>
                  <div className="small">Inbound</div>
                  <div className="times">
                    <div><div className="badge">{timeHHMM(depIn)}</div></div>
                    <div><div className="badge">{stopsIn? `${stopsIn} stops` : 'direct'}</div></div>
                    <div><div className="badge">{timeHHMM(arrIn)}</div></div>
                  </div>
                </div>}
              </div>
              <div style={{display:'flex',flexDirection:'column',gap:8,alignItems:'flex-end'}}>
                <div style={{fontWeight:900,fontSize:20}}>{priceText(offer)}</div>
                <a className="btn" href={"/review"}>Select</a>
                <a className="btn ghost" href={"/checkout"}>Lock price</a>
              </div>
            </div>
          )
        })}

        <div className="footerbar">
          <button className="btn ghost">Filters</button>
          <button className="btn">Sort</button>
        </div>
      </div>
    </div>
  )
}
