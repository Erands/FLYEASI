import Header from '@/components/Header'
export default function Checkout(){
  return (<div><Header/><div className="container"><div className="card"><b>Checkout</b><p>Traveler + payment form goes here.</p></div></div></div>)
}
