import {useState} from 'react'
import Header from '@/components/Header'
import { getQueryString } from '@/lib/utils'
import { useRouter } from 'next/router'

export default function Home(){
  const r = useRouter()
  const [trip, setTrip] = useState('oneway')
  const [form, setForm] = useState({
    origin:'', destination:'', departure_date:'', return_date:'',
    adults:1, cabin:'ECONOMY'
  })
  function upd(k,v){ setForm(s => ({...s, [k]:v})) }
  function submit(e){
    e.preventDefault()
    const q = getQueryString({...form, trip})
    r.push('/results?'+q)
  }
  return (
    <div>
      <Header/>
      <div className="container">
        <div className="card">
          <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:8}}>
            <button className={"btn "+(trip==='oneway'?'':'ghost')} onClick={()=>setTrip('oneway')}>One‑way</button>
            <button className={"btn "+(trip==='return'?'':'ghost')} onClick={()=>setTrip('return')}>Return</button>
            <button className={"btn "+(trip==='multicity'?'':'ghost')} onClick={()=>setTrip('multicity')}>Multi‑city</button>
          </div>
          <form onSubmit={submit} className="input-row">
            <div className="field"><label>From</label><input placeholder="City or code" value={form.origin} onChange={e=>upd('origin',e.target.value)} required/></div>
            <button type="button" className="btn ghost swap" onClick={()=>{const a=form.origin; upd('origin',form.destination); upd('destination',a)}}>Swap</button>
            <div className="field"><label>To</label><input placeholder="City or code" value={form.destination} onChange={e=>upd('destination',e.target.value)} required/></div>
            <div className="field"><label>Departure</label><input type="date" value={form.departure_date} onChange={e=>upd('departure_date',e.target.value)} required/></div>
            <div className="field"><label>Return</label><input type="date" value={form.return_date} disabled={trip!=='return'} onChange={e=>upd('return_date',e.target.value)}/></div>
            <div><button className="btn" type="submit">Search</button></div>
          </form>
          <div style={{display:'flex',gap:8,marginTop:8}}>
            <div className="field"><label>Cabin</label>
              <select value={form.cabin} onChange={e=>upd('cabin',e.target.value)}>
                <option>ECONOMY</option><option>PREMIUM_ECONOMY</option><option>BUSINESS</option><option>FIRST</option>
              </select>
            </div>
            <div className="field"><label>Adults</label>
              <select value={form.adults} onChange={e=>upd('adults',Number(e.target.value))}>
                {Array.from({length:9}).map((_,i)=> <option key={i+1} value={i+1}>{i+1}</option>)}
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
