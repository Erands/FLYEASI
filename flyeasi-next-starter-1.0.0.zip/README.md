# Flyeasi Next Starter (No PHP)
A minimal, mobile-friendly flight search UI (Kiwi-style) with a serverless API proxy to Tiqwa.  
Pages included: **Home/Search**, **Results**, **Review**, **Checkout**.

## 1) Deploy (no coding)
**Vercel (recommended):**
1. Create a new project on https://vercel.com → "Import" → select this folder/repo.
2. Set Environment Variables:
   - `TIQWA_BASE_URL` = `https://sandbox.tiqwa.com`
   - `TIQWA_SEARCH_PATH` = `/v1/flights/search` (or paste the full URL here)
   - `TIQWA_METHOD` = `POST`
   - `TIQWA_TOKEN` = `your_tiqwa_token_here`
3. Deploy. Open your domain → you'll see the Search page at `/` and Results at `/results`.

**Netlify:**
1. New site from Git → pick this repo.
2. Build command: `npm run build` ; Publish directory: `.next`
3. Environment variables: same as above.
4. Deploy.

## 2) How it works
- The **Search** page builds a query string and navigates to `/results`.
- The **Results** page POSTs to **/api/search** with a normalized payload (IATA codes only).
- The serverless route **/api/search** calls your Tiqwa endpoint using your env vars.
- If the first path returns **404**, it tries two common alternates:
  - `/v1/flights/search`
  - `/v1/flight/flights/search`
- The UI shows **Best/Cheapest/Fastest** pills and responsive Kiwi-style cards.

## 3) Configure your exact endpoint
- Prefer **full absolute URL** in `TIQWA_SEARCH_PATH`, e.g.  
  `https://sandbox.tiqwa.com/v1/flights/search`
- Or use `TIQWA_BASE_URL = https://sandbox.tiqwa.com` and `TIQWA_SEARCH_PATH = /v1/flights/search`.

If you see:
- **404**: wrong path — try `.../v1/flight/flights/search`.
- **405**: change `TIQWA_METHOD` to GET or POST accordingly.
- **500**: Tiqwa returned an internal error (check logs).

## 4) Embed in WordPress (optional)
If you want this on your current domain, deploy it on Vercel (e.g. `app.flyeasi.com`) and embed with an `<iframe>` in a WordPress page.

## 5) Dev
- `npm install`
- `npm run dev` → http://localhost:3000

---
Owner/Developer: **Erands Technology Team**.
