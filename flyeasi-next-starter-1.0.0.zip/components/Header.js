import Link from 'next/link'
export default function Header(){
  return (
    <div className="container header">
      <div className="brand">
        <img src="/logo.svg" width={28} height={28} alt="logo" />
        Flyeasi
      </div>
      <nav className="nav">
        <Link href="/"><span className="small">Search</span></Link>
        <Link href="/results"><span className="small">Results</span></Link>
        <Link href="/review"><span className="small">Review</span></Link>
        <Link href="/checkout"><span className="small">Checkout</span></Link>
      </nav>
    </div>
  )
}
